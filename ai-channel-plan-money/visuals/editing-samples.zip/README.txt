編集提案・改訂3。K1/K2はAI生成の生活場面の配置見本。K3/K4は自作図解。完成動画ではありません。図解は説明項目を限定した簡略図です。出典・編集例は公開資料を参照。
https://tanakayuc.github.io/static-pages/ai-channel-plan-money/visuals/
